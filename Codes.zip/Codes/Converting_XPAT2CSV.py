
import xport, csv
import os
import pandas as pd

xpt_files = []
xpt_full_files = []
#The directory name where the XPT files are
input_dir = 'D:/Personal/UNT/Courses/DSCI 5240 - Data Mining/Final Project/Data/'
'''
#Creates a list of the XPT files in input_dir
for file in os.listdir(input_dir):
    if file.upper().endswith(".XPT"):
        xpt_files.append(file)
'''
for root, subs, files in os.walk(input_dir): 
   for file in files:
       if file.upper().endswith(".XPT"):
           xpt_full_files.append(os.path.join(root, file))

           
#Converts XPT files to CSV files with the same name in the same directory
for f in xpt_full_files:
    print ('reading '+f+' now')
    csv_name = f.upper().replace ('XPT','csv')
    df=pd.read_sas(f)
    df.to_csv(csv_name, float_format='%.3f', index=False, quoting=csv.QUOTE_NONE, quotechar="")
