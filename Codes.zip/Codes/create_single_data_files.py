import pandas as pd
import numpy as np
import matplotlib.pyplot as plt  # To visualize
import os
import re


BPX_Cols = ['SEQN', 'BPXSY1', 'BPXDI1', 'BPXSY2', 'BPXDI2', 'BPXSY3', 
            'BPXDI3', 'BPXPLS', 'BPXPULS'] #cols to be read from Blood Pressure (BPX_J) file

BPQ_Cols = ['SEQN', 'BPQ020', 'BPQ080'] #cols to be read from Blood Pressure & Cholesterol (BPQ)

HSQ_Cols = ['SEQN', 'HSD010'] #cols to be read from Current Health Status (HSQ)

DEMO_Cols = ['SEQN', 'RIAGENDR', 'RIDAGEYR', 'RIDRETH1', 'RIDEXPRG', 'INDHHIN2', 'INDFMPIR'] #cols to be read from Demographic Variables & Sample Weights (DEMO_G)

DIQ_Cols = ['SEQN', 'DIQ010', 'DIQ160', 'DIQ170'] #cols to be read from Diabetes (DIQ)

DBQ_Cols = ['SEQN', 'DBQ700', 'DBD895'] #cols to be read from Diet Behavior & Nutrition (DBQ)

DR1TOT_Cols = ['SEQN', 'DBD100', 'DR1TSUGR'] #cols to be read from Dietary Interview - Total Nutrient Intakes, First Day (DR1TOT)
DR2TOT_Cols = ['SEQN', 'DR2TSUGR'] #cols to be read from Dietary Interview - Total Nutrient Intakes, Second Day (DR2TOT)

DUQ_Cols = ['SEQN', 'DUQ200'] #cols to be read from Drug Use (DUQ)

BMX_Cols = ['SEQN', 'BMXBMI'] #cols to be read from Body Measures (BMX)

HEQ_Cols = ['SEQN', 'HEQ010', 'HEQ030'] #cols to be read from Hepatitis (HEQ)

HUQ_Cols = ['SEQN', 'HUQ010'] #cols to be read from Hospital Utilization & Access to Care (HUQ)

KIQ_Cols = ['SEQN', 'KIQ022'] #cols to be read from Kidney Condition (KIQ)

BIOPRO_Cols = ['SEQN', 'LBXSTR', 'LBXSUA', 'LBXSNASI', 'LBXSCA', 'LBXSTP', 'LBXSAL', 
               'LBXSAPSI', 'LBXSASSI', 'LBXSBU', 'LBXSCLSI', 'LBXSCR', 'LBXSGB', 'LBXSGL', 
               'LBXSIR', 'LBXSOSSI', 'LBXSPH', 'LBXSKSI' ] #cols to be read from Standard Biochemistry Profile (BIOPRO)

TCHOL_Cols = ['SEQN', 'LBXTC'] #cols to be read from Cholesterol - Total (TCHOL)

HDL_Cols = ['SEQN', 'LBDHDD'] #cols o be read from Cholesterol - High - Density Lipoprotein (HDL) (HDL)

MCQ_Cols = ['SEQN', 'MCQ080', 'MCQ160C', 'MCQ160E'] #cols to be read from Medical Conditions (MCQ)

DPQ_Cols = ['SEQN', 'DPQ010'] #cols to be read from Mental Health (DPQ)

PAQ_Cols = ['SEQN', 'PAQ605', 'PAQ635', 'PAQ650'] #cols to be read from Physical Activity (PAQ)
PFQ_Cols = ['SEQN', 'PFQ059'] #cols to be read from Physical Functioning (PFQ)

SLQ_Cols = ['SEQN', 'SLQ050'] #cols to be read from Sleep (SLQ)

SMQ_Cols = ['SEQN', 'SMQ020', 'SMQ040'] #cols to be read from Smoking (SMQ)

WHQ_Cols = ['SEQN', 'WHQ030'] #cols to be read from Weight History (WHQ)



#read the csv files and create dataframes
#The upmost directory path where the csv files for a single year are located in
data_year_list = ['2009-2010', '2011-2012', '2013-2014', '2015-2016', '2017-2018']
all_year_df = pd.DataFrame()

#read data type from the excel file
var_file = 'D:/Personal/UNT/Courses/DSCI 5240 - Data Mining/Final Project/Data/variable_type.csv'
var_df = pd.read_csv (var_file)
dtype_dic = var_df.set_index('var_name').to_dict()['var_type']


for data_year in data_year_list:
    input_dir = 'D:/Personal/UNT/Courses/DSCI 5240 - Data Mining/Final Project/Data/'+data_year+'/'
    csv_full_files = []
#csv_file_names = []

    for root, subs, files in os.walk(input_dir): 
        for file in files:
            if file.upper().endswith(".CSV"):
                csv_full_files.append(os.path.join(root, file))
           #csv_file_names.append(file)

#read BPX file and create dataframe
    r = re.compile('.*BPX')
    BPX_file_name = list(filter(r.match, csv_full_files))
    BPX_df = pd.read_csv(BPX_file_name[0], usecols=BPX_Cols, dtype=dtype_dic)
    #take averages of three reading for systolic and diastolic
    systolic_ave = BPX_df[['BPXSY1','BPXSY2','BPXSY3']].mean(axis=1)
    diastolic_ave = BPX_df[['BPXDI1','BPXDI2','BPXDI3']].mean(axis=1)
    #add average columns to the df
    BPX_df.insert(1,'systolic_ave', systolic_ave)
    BPX_df.insert(2,'diastolic_ave', diastolic_ave)
    #drop original blood pressure value columns
    BPX_df.drop(labels=['BPXSY1','BPXSY2','BPXSY3','BPXDI1','BPXDI2','BPXDI3'], axis=1, inplace=True)
    #drop empty rows
    BPX_df.dropna(axis=0, how='any', inplace=True)
    BPX_df.reset_index(drop=True, inplace=True)
    #create a column for hypertension classs label
    Hyp_Class = []
    for i in range(BPX_df.shape[0]):
        if BPX_df['systolic_ave'][i]<130 and BPX_df['diastolic_ave'][i]<80:
            Hyp_Class.append(False)
        else:
            Hyp_Class.append(True)
    BPX_df.insert(3, 'hypertension', Hyp_Class)
    #remove duplicate records
    BPX_df.drop_duplicates(subset=['SEQN'], inplace=True)

    #read BPQ file and create dataframe
    r = re.compile('.*BPQ')
    csv_file_name = list(filter(r.match, csv_full_files))
    new_df = pd.read_csv(csv_file_name[0], usecols=BPQ_Cols, dtype=dtype_dic)
    #inner join new_df with BPX_df
    BPX_df=BPX_df.join(new_df.set_index('SEQN'), on='SEQN',  how='inner')
    #remove duplicate records
    BPX_df.drop_duplicates(subset=['SEQN'], inplace=True)
    
    
    #read HSQ file and create dataframe
    r = re.compile('.*HSQ')
    csv_file_name = list(filter(r.match, csv_full_files))
    new_df = pd.read_csv(csv_file_name[0], usecols=HSQ_Cols, dtype=dtype_dic)
    #inner join new_df with BPX_df
    BPX_df=BPX_df.join(new_df.set_index('SEQN'), on='SEQN',  how='inner')
    #remove duplicate records
    BPX_df.drop_duplicates(subset=['SEQN'], inplace=True)
    
    
    #read DEMO file and create dataframe
    r = re.compile('.*DEMO')
    csv_file_name = list(filter(r.match, csv_full_files))
    new_df = pd.read_csv(csv_file_name[0], usecols=DEMO_Cols, dtype=dtype_dic)
    #inner join new_df with BPX_df
    BPX_df=BPX_df.join(new_df.set_index('SEQN'), on='SEQN',  how='inner')
    #remove duplicate records
    BPX_df.drop_duplicates(subset=['SEQN'], inplace=True)


    #read DIQ file and create dataframe
    r = re.compile('.*DIQ')
    csv_file_name = list(filter(r.match, csv_full_files))
    new_df = pd.read_csv(csv_file_name[0], usecols=DIQ_Cols, dtype=dtype_dic)
    #inner join new_df with BPX_df
    BPX_df=BPX_df.join(new_df.set_index('SEQN'), on='SEQN',  how='inner')
    #remove duplicate records
    BPX_df.drop_duplicates(subset=['SEQN'], inplace=True)
    
    
    #read DBQ file and create dataframe
    r = re.compile('.*DBQ')
    csv_file_name = list(filter(r.match, csv_full_files))
    new_df = pd.read_csv(csv_file_name[0], usecols=DBQ_Cols, dtype=dtype_dic)
    #inner join new_df with BPX_df
    BPX_df=BPX_df.join(new_df.set_index('SEQN'), on='SEQN',  how='inner')
    #remove duplicate records
    BPX_df.drop_duplicates(subset=['SEQN'], inplace=True)
    
    
    #read DR1TOT file and create dataframe
    r = re.compile('.*DR1TOT')
    csv_file_name = list(filter(r.match, csv_full_files))
    new_df = pd.read_csv(csv_file_name[0], usecols=DR1TOT_Cols, dtype=dtype_dic)
    #inner join new_df with BPX_df
    BPX_df=BPX_df.join(new_df.set_index('SEQN'), on='SEQN',  how='inner')
    #remove duplicate records
    BPX_df.drop_duplicates(subset=['SEQN'], inplace=True)

    
    #read DR2TOT file and create dataframe
    r = re.compile('.*DR2TOT')
    csv_file_name = list(filter(r.match, csv_full_files))
    new_df = pd.read_csv(csv_file_name[0], usecols=DR2TOT_Cols, dtype=dtype_dic)
    #inner join new_df with BPX_df
    BPX_df=BPX_df.join(new_df.set_index('SEQN'), on='SEQN',  how='inner')
    #remove duplicate records
    BPX_df.drop_duplicates(subset=['SEQN'], inplace=True)
    
    
    #read DUQ file and create dataframe
    r = re.compile('.*DUQ')
    csv_file_name = list(filter(r.match, csv_full_files))
    new_df = pd.read_csv(csv_file_name[0], usecols=DUQ_Cols, dtype=dtype_dic)
    #inner join new_df with BPX_df
    BPX_df=BPX_df.join(new_df.set_index('SEQN'), on='SEQN',  how='inner')
    #remove duplicate records
    BPX_df.drop_duplicates(subset=['SEQN'], inplace=True)
    
    
    #read BMX file and create dataframe
    r = re.compile('.*BMX')
    csv_file_name = list(filter(r.match, csv_full_files))
    new_df = pd.read_csv(csv_file_name[0], usecols=BMX_Cols, dtype=dtype_dic)
    #inner join new_df with BPX_df
    BPX_df=BPX_df.join(new_df.set_index('SEQN'), on='SEQN',  how='inner')
    #remove duplicate records
    BPX_df.drop_duplicates(subset=['SEQN'], inplace=True)
    
    '''
    #read HEQ file and create dataframe
    r = re.compile('.*HEQ')
    csv_file_name = list(filter(r.match, csv_full_files))
    new_df = pd.read_csv(csv_file_name[0], usecols=HEQ_Cols)
    #inner join new_df with BPX_df
    BPX_df=BPX_df.join(new_df.set_index('SEQN'), on='SEQN',  how='inner')
    
    '''
    #read HUQ file and create dataframe
    r = re.compile('.*HUQ')
    csv_file_name = list(filter(r.match, csv_full_files))
    new_df = pd.read_csv(csv_file_name[0], usecols=HUQ_Cols, dtype=dtype_dic)
    #inner join new_df with BPX_df
    BPX_df=BPX_df.join(new_df.set_index('SEQN'), on='SEQN',  how='inner')
    #remove duplicate records
    BPX_df.drop_duplicates(subset=['SEQN'], inplace=True)
    
    
    #read KIQ file and create dataframe
    r = re.compile('.*KIQ')
    csv_file_name = list(filter(r.match, csv_full_files))
    new_df = pd.read_csv(csv_file_name[0], usecols=KIQ_Cols, dtype=dtype_dic)
    #inner join new_df with BPX_df
    BPX_df=BPX_df.join(new_df.set_index('SEQN'), on='SEQN',  how='inner')
    #remove duplicate records
    BPX_df.drop_duplicates(subset=['SEQN'], inplace=True)
    
    
    #read BIOPRO file and create dataframe
    r = re.compile('.*BIOPRO')
    csv_file_name = list(filter(r.match, csv_full_files))
    new_df = pd.read_csv(csv_file_name[0], usecols=BIOPRO_Cols, dtype=dtype_dic)
    #inner join new_df with BPX_df
    BPX_df=BPX_df.join(new_df.set_index('SEQN'), on='SEQN',  how='inner')
    #remove duplicate records
    BPX_df.drop_duplicates(subset=['SEQN'], inplace=True)
    
    #read TCHOL file and create dataframe
    r = re.compile('.*TCHOL')
    csv_file_name = list(filter(r.match, csv_full_files))
    new_df = pd.read_csv(csv_file_name[0], usecols=TCHOL_Cols, dtype=dtype_dic)
    #inner join new_df with BPX_df
    BPX_df=BPX_df.join(new_df.set_index('SEQN'), on='SEQN',  how='inner')
    #remove duplicate records
    BPX_df.drop_duplicates(subset=['SEQN'], inplace=True)
    
    
    #read HDL file and create dataframe
    r = re.compile('.*HDL')
    csv_file_name = list(filter(r.match, csv_full_files))
    new_df = pd.read_csv(csv_file_name[0], usecols=HDL_Cols, dtype=dtype_dic)
    #inner join new_df with BPX_df
    BPX_df=BPX_df.join(new_df.set_index('SEQN'), on='SEQN',  how='inner')
    #remove duplicate records
    BPX_df.drop_duplicates(subset=['SEQN'], inplace=True)
    
    
    #read MCQ file and create dataframe
    r = re.compile('.*MCQ')
    csv_file_name = list(filter(r.match, csv_full_files))
    new_df = pd.read_csv(csv_file_name[0], usecols=MCQ_Cols, dtype=dtype_dic)
    #inner join new_df with BPX_df
    BPX_df=BPX_df.join(new_df.set_index('SEQN'), on='SEQN',  how='inner')
    #remove duplicate records
    BPX_df.drop_duplicates(subset=['SEQN'], inplace=True)
    
    
    #read DPQ file and create dataframe
    r = re.compile('.*DPQ')
    csv_file_name = list(filter(r.match, csv_full_files))
    new_df = pd.read_csv(csv_file_name[0], usecols=DPQ_Cols, dtype=dtype_dic)
    #inner join new_df with BPX_df
    BPX_df=BPX_df.join(new_df.set_index('SEQN'), on='SEQN',  how='inner')
    #remove duplicate records
    BPX_df.drop_duplicates(subset=['SEQN'], inplace=True)
    
    
    #read PAQ file and create dataframe
    r = re.compile('.*PAQ')
    csv_file_name = list(filter(r.match, csv_full_files))
    new_df = pd.read_csv(csv_file_name[0], usecols=PAQ_Cols, dtype=dtype_dic)
    #inner join new_df with BPX_df
    BPX_df=BPX_df.join(new_df.set_index('SEQN'), on='SEQN',  how='inner')
    #remove duplicate records
    BPX_df.drop_duplicates(subset=['SEQN'], inplace=True)
    

    #read PFQ file and create dataframe
    r = re.compile('.*PFQ')
    csv_file_name = list(filter(r.match, csv_full_files))
    new_df = pd.read_csv(csv_file_name[0], usecols=PFQ_Cols, dtype=dtype_dic)
    #inner join new_df with BPX_df
    BPX_df=BPX_df.join(new_df.set_index('SEQN'), on='SEQN',  how='inner')
    #remove duplicate records
    BPX_df.drop_duplicates(subset=['SEQN'], inplace=True)


    #read SLQ file and create dataframe
    r = re.compile('.*SLQ')
    csv_file_name = list(filter(r.match, csv_full_files))
    new_df = pd.read_csv(csv_file_name[0], usecols=SLQ_Cols, dtype=dtype_dic)
    #inner join new_df with BPX_df
    BPX_df=BPX_df.join(new_df.set_index('SEQN'), on='SEQN',  how='inner')
    #remove duplicate records
    BPX_df.drop_duplicates(subset=['SEQN'], inplace=True)
    

    #read SMQ file and create dataframe
    r = re.compile('.*SMQ')
    csv_file_name = list(filter(r.match, csv_full_files))
    new_df = pd.read_csv(csv_file_name[0], usecols=SMQ_Cols, dtype=dtype_dic)
    #inner join new_df with BPX_df
    BPX_df=BPX_df.join(new_df.set_index('SEQN'), on='SEQN',  how='inner')
    #remove duplicate records
    BPX_df.drop_duplicates(subset=['SEQN'], inplace=True)


    #read WHQ file and create dataframe
    r = re.compile('.*WHQ')
    csv_file_name = list(filter(r.match, csv_full_files))
    new_df = pd.read_csv(csv_file_name[0], usecols=WHQ_Cols, dtype=dtype_dic)
    #inner join new_df with BPX_df
    BPX_df=BPX_df.join(new_df.set_index('SEQN'), on='SEQN',  how='inner')
    #remove duplicate records
    BPX_df.drop_duplicates(subset=['SEQN'], inplace=True)



    #add year column to the df
    BPX_df.insert (1,'year', [data_year for i in range(BPX_df.shape[0])])
    
    #calculate average 
    #write the merged DF into a csv file
    print ('now saving: '+data_year)
    BPX_df.to_csv('Merged_Data_'+data_year+'.csv', index = False)
    all_year_df = pd.concat([all_year_df,BPX_df])
    
    
all_year_df.to_csv('Merged_Data_All_Years.csv',header=True, index = False)